import type { Certification } from "../types";

// TODO: add the real "date earned" and credential / verification URL for each.
export const certifications: Certification[] = [
  {
    id: "azure-ai-fundamentals",
    title: "Microsoft Certified: Azure AI Fundamentals",
    issuer: "Microsoft",
    date: "Add date",
    credentialUrl: "",
  },
  {
    id: "ms-ai-skills-fest",
    title: "Microsoft AI Skills Fest Achievement",
    issuer: "Microsoft",
    date: "Add date",
    credentialUrl: "",
  },
  {
    id: "aws-agentic-ai",
    title: "AWS Agentic AI Demonstrated Microcredential",
    issuer: "AWS",
    date: "Add date",
    credentialUrl: "",
  },
];
