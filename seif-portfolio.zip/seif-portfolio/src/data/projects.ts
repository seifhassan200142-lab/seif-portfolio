import type { Project } from "../types";

// ---------------------------------------------------------------------------
// PROJECTS
// To add a screenshot: drop an image in /public/projects/ and set `image`
// to its path, e.g. "/projects/nabd-ai.png". Update githubUrl / liveUrl
// with the real repository and demo links.
// ---------------------------------------------------------------------------

export const projects: Project[] = [
  {
    id: "nabd-ai",
    title: "Nabd AI — Medical RAG & Hospital AI Assistant",
    description:
      "A healthcare AI assistant designed to support medical workflows using Arabic input, guardrails, query mapping, hybrid retrieval, RAG, citations, and doctor-reviewed AI outputs.",
    problem:
      "Medical teams need safe, grounded, and well-documented AI assistance that supports their workflow without replacing clinicians.",
    solution:
      "Nabd AI uses guardrails, medical query mapping, hybrid retrieval, reranking, grounded generation, and citations to support healthcare workflows as a draft layer with doctor review.",
    techStack: [
      "Python",
      "FastAPI",
      "Qdrant",
      "LangChain",
      "Hugging Face",
      "Sentence Transformers",
      "CrossEncoder",
      "Groq / LLaMA",
      "RAG",
      "BM25",
      "Reranking",
    ],
    githubUrl: "https://github.com/your-username/nabd-ai",
    liveUrl: "",
    featured: true,
  },
  {
    id: "internal-docs-rag",
    title: "Internal Docs RAG Assistant",
    description:
      "A production-style RAG assistant that allows users to upload internal documents and ask questions with grounded answers and citations.",
    techStack: [
      "Python",
      "FastAPI",
      "Streamlit",
      "FAISS",
      "Qdrant",
      "Sentence Transformers",
      "RAG",
      "Hybrid Search",
      "Reranking",
    ],
    githubUrl: "https://github.com/your-username/internal-docs-rag",
    liveUrl: "",
  },
  {
    id: "ai-operations-agent",
    title: "AI Operations Agent",
    description:
      "An AI operations assistant that understands requests, selects tools, executes multi-step workflows, summarizes tickets, drafts emails, uses a calculator, interacts with a local database, and requires human approval before sensitive actions.",
    techStack: [
      "Python",
      "FastAPI",
      "SQLite",
      "Tool Calling",
      "AI Agents",
      "Human Approval Workflow",
    ],
    githubUrl: "https://github.com/your-username/ai-operations-agent",
    liveUrl: "",
  },
  {
    id: "domain-lora-finetuning",
    title: "Domain LoRA Fine-tuning Pipeline",
    description:
      "A lightweight educational fine-tuning pipeline for adapting a small open-source language model to structured customer support response formatting.",
    techStack: ["Python", "Hugging Face", "PEFT", "LoRA", "Transformers", "Datasets"],
    githubUrl: "https://github.com/your-username/domain-lora-finetuning",
    liveUrl: "",
  },
  {
    id: "talk-to-your-data",
    title: "Talk to Your Data",
    description:
      "A local analytics assistant that lets users query tabular data, generate insights, explore dashboards, and interact with data using natural language.",
    techStack: ["Python", "Streamlit", "DuckDB", "FAISS", "Plotly", "Ollama", "Sentence Transformers"],
    githubUrl: "https://github.com/your-username/talk-to-your-data",
    liveUrl: "",
  },
  {
    id: "real-estate-price-prediction",
    title: "Real Estate Price Prediction",
    description:
      "A machine learning regression project for predicting real estate prices in Egypt using cleaned listing data, feature engineering, and model evaluation.",
    techStack: ["Python", "Pandas", "Scikit-learn", "Regression", "Data Cleaning", "Feature Engineering"],
    githubUrl: "https://github.com/your-username/real-estate-price-prediction",
    liveUrl: "",
  },
];
